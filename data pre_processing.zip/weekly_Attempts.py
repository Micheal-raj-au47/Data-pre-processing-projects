
def Total_Attempts(df1):
    Columns= df1[["event_timestamp", "customer_id", "asin", "pdsn", "authorization_origin_type"]]
    df5=df1.groupby('customer_id').agg(Attempts=('customer_id','count'))
    res1=df5.to_csv("Overall_attempts.csv")
    return df5