import pandas as pd
import matplotlib.pyplot as plt
from weekly_Attempts import Total_Attempts
from Weekly_bad_Actors import Bad_Actors


filename=input("Enter your Filepath: ")
df=pd.read_csv(filename)
df=df[["event_timestamp","customer_id","asin","pdsn","authorization_origin_type"]]
df1=df.copy()

def main():
    Attempts=Total_Attempts(df1)
    Actors=Bad_Actors(df1)
    same_values = pd.merge(Attempts, Actors, on=["customer_id", "customer_id"])
    result = same_values[["customer_id", "Attempts"]]
    aggre=result.sort_values(by="Attempts", ascending=False , ignore_index=True)
    #aggre=aggre.reset_index(drop=True)
    #aggre = result.apply(lambda result: result.sort_values(by='Attempts', ascending=True))

    Final=aggre.to_csv("required_bad_actors_attempts.csv" , index=False)
    fig, ax = plt.subplots(figsize=(12, 8))
    ax.scatter(result['customer_id'], result['Attempts'], color='red')

    # add title and labels
    ax.set_title('Bad_Actors')
    ax.set_xlabel('Final')
    ax.set_ylabel('Attempts')

    # Save the figure
    plt.savefig('Bad_actors_list.png')

    # display the plot
    plt.show()

if __name__ == "__main__":
    main()

