import pandas as pd

def Bad_Actors(df1):
    col= df1[["event_timestamp", "customer_id", "asin", "pdsn", "authorization_origin_type"]]
    Start_Date=input("Enter the start date in YYYY-MM-DD: ")
    End_Date=input("Enter the End date in YYYY-MM-DD: ")
    Start_Date=pd.to_datetime(Start_Date).date()
    End_Date=pd.to_datetime(End_Date).date()
    df1["event_timestamp"]=pd.to_datetime(df1["event_timestamp"]).dt.date
    df2=df1[(df1['event_timestamp'] >=Start_Date) & (df1['event_timestamp'] <=End_Date)]
    df2.reset_index(drop=True,inplace=True)
    df4=df2.drop_duplicates(subset=['customer_id'])
    return df4
